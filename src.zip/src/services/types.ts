export type setFromTextType = (text: string) => void
export type setToTextType = (text: string) => void
